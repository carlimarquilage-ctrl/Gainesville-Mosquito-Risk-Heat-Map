/** Transparent continuous mosquito-risk model (0–100). */
const RISK_GRADIENT = {
  0.00: '#16803a', 0.20: '#55b947', 0.40: '#cddd3a',
  0.60: '#ffd43b', 0.80: '#ff7a28', 1.00: '#d7191c'
};

const clamp01 = value => Math.max(0, Math.min(1, value));

function rainfallSubscore(days) {
  const weighted = days.reduce((sum, value, i) => sum + Math.max(0, value || 0) * RAIN_DAY_WEIGHTS[i], 0);
  const weightTotal = RAIN_DAY_WEIGHTS.reduce((a, b) => a + b, 0);
  return clamp01((weighted / weightTotal) / 0.55);
}

function temperatureSubscore(days) {
  const valid = days.filter(Number.isFinite);
  const avg = valid.length ? valid.reduce((a, b) => a + b, 0) / valid.length : 78;
  return clamp01(Math.exp(-0.5 * ((avg - 82) / 10) ** 2));
}

function waterProximitySubscore(lat, lng, bodies) {
  if (!bodies.length) return 0;
  let influence = 0;
  bodies.forEach(body => {
    const distance = distanceKm(lat, lng, body.lat, body.lng);
    influence += (body.weight || 0.8) * Math.exp(-distance / WATER_INFLUENCE_KM);
  });
  return clamp01(1 - Math.exp(-influence));
}

function reportSubscore(lat, lng, reports) {
  let influence = 0;
  reports.forEach(report => {
    const distance = distanceKm(lat, lng, report.lat, report.lng);
    const evidence = report.larvaeCount > 0 ? 0.65 + Math.min(report.larvaeCount, 20) / 40 : 0.08;
    influence += evidence * Math.exp(-distance / REPORT_INFLUENCE_KM);
  });
  return clamp01(1 - Math.exp(-influence));
}

function continuousScore(rain, temp, water, report) {
  const totalWeight = RISK_WEIGHTS.rain + RISK_WEIGHTS.temp + RISK_WEIGHTS.water + RISK_WEIGHTS.report;
  return 100 * clamp01((rain * RISK_WEIGHTS.rain + temp * RISK_WEIGHTS.temp +
    water * RISK_WEIGHTS.water + report * RISK_WEIGHTS.report) / totalWeight);
}

function computeGridRisk(grid, weather, waterBodies, reports) {
  return grid.map((point, index) => {
    const rainScore = rainfallSubscore(weather.rain[index] || FALLBACK_RAIN7);
    const tempScore = temperatureSubscore(weather.temp[index] || FALLBACK_TEMP7);
    const waterScore = waterProximitySubscore(point.lat, point.lng, waterBodies);
    const reportScore = reportSubscore(point.lat, point.lng, reports);
    const risk = continuousScore(rainScore, tempScore, waterScore, reportScore);
    return { ...point, risk, rawScore: risk, rainScore, tempScore, waterScore, reportScore,
      tier: risk >= 70 ? 'high' : risk >= 35 ? 'medium' : 'low' };
  });
}

function nearestGridIndex(lat, lng) {
  const row = Math.round(clamp01((lat - COUNTY_BBOX.south) / (COUNTY_BBOX.north - COUNTY_BBOX.south)) * (GRID_SIZE - 1));
  const col = Math.round(clamp01((lng - COUNTY_BBOX.west) / (COUNTY_BBOX.east - COUNTY_BBOX.west)) * (GRID_SIZE - 1));
  return row * GRID_SIZE + col;
}

function interpolateGridRisk(lat, lng, values) {
  const rowPos = clamp01((lat - COUNTY_BBOX.south) / (COUNTY_BBOX.north - COUNTY_BBOX.south)) * (GRID_SIZE - 1);
  const colPos = clamp01((lng - COUNTY_BBOX.west) / (COUNTY_BBOX.east - COUNTY_BBOX.west)) * (GRID_SIZE - 1);
  const r0 = Math.floor(rowPos), c0 = Math.floor(colPos);
  const r1 = Math.min(r0 + 1, GRID_SIZE - 1), c1 = Math.min(c0 + 1, GRID_SIZE - 1);
  const fr = rowPos - r0, fc = colPos - c0;
  const at = (r, c) => values[r * GRID_SIZE + c].risk;
  return at(r0,c0)*(1-fr)*(1-fc) + at(r1,c0)*fr*(1-fc) + at(r0,c1)*(1-fr)*fc + at(r1,c1)*fr*fc;
}

function citywideDailyAverage(rows) {
  return Array.from({length: 7}, (_, day) => rows.reduce((sum, row) => sum + (row[day] || 0), 0) / Math.max(rows.length, 1));
}
function tierColor(tier) { return tier === 'high' ? '#d7191c' : tier === 'medium' ? '#e59b16' : '#16803a'; }
function tierBg(tier) { return tier === 'high' ? '#fee2e2' : tier === 'medium' ? '#fef3c7' : '#dcfce7'; }
function tierLabel(tier) { return tier === 'high' ? 'High risk' : tier === 'medium' ? 'Moderate risk' : 'Low risk'; }
