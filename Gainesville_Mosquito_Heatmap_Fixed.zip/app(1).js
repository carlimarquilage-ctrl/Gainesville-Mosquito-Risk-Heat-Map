(async function init() {

  /* ---------------- Step 1: Base Map Setup ---------------- */
  const map = L.map('map', {
    zoomControl: true,
    attributionControl: true,
    minZoom: 10,
    maxZoom: 16,
    maxBounds: MAP_BOUNDS,
    maxBoundsViscosity: 0.9
  }).setView(COUNTY_CENTER, 11);

  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 16,
    attribution: 'Tiles &copy; Esri &mdash; Esri, HERE, Garmin, &copy; OpenStreetMap contributors'
  }).addTo(map);

  const grid = buildGrid();

  /* ---------------- Step 2: Parallel Live Data Retrieval ---------------- */
  const [globeRes, weatherRes, waterRes] = await Promise.all([
    fetchGlobeSites(),
    fetchWeatherGrid(grid),
    fetchWaterBodies()
  ]);

  const loadingEl = document.getElementById('loading');
  if (loadingEl) loadingEl.style.display = 'none';

  /* ---------------- Step 3: Status Badges ---------------- */
  updateStatusBadge('status-globe', 'GLOBE Observer', globeRes.live);
  updateStatusBadge('status-rain', 'Open-Meteo Weather', weatherRes.live);
  updateStatusBadge('status-water', 'OSM Water Bodies', waterRes.live);

  function updateStatusBadge(elementId, label, isLive) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const badgeClass = isLive ? 'src-live' : 'src-fallback';
    const badgeText = isLive ? 'LIVE' : 'FALLBACK';
    el.innerHTML = `<span class="src-badge ${badgeClass}">${badgeText}</span> ${label}`;
  }

  /* ---------------- Step 4: Calculate Base Risk Scores ---------------- */
  const gridRisk = computeGridRisk(grid, weatherRes.data, waterRes.data, globeRes.data);
  const dailyAvgRain = citywideDailyAverage(weatherRes.data.rain);
  const rain7dTotal = dailyAvgRain.reduce((a, b) => a + b, 0);

  /* ---------------- Step 5: Stable, continuous heatmap surface ---------------- */
  // Each pixel samples the same geographic scalar field as the click popup.
  // No additive dots, zoom-dependent weights, or viewport normalization.
  const stops = Object.entries(RISK_GRADIENT)
    .map(([position, hex]) => ({
      position: Number(position),
      rgb: [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16))
    })).sort((a, b) => a.position - b.position);
  function riskRGB(score) {
    const t = clamp01(score / 100);
    const upper = stops.findIndex(stop => stop.position >= t);
    const hi = stops[Math.max(0, upper)];
    const lo = stops[Math.max(0, upper - 1)];
    const fraction = hi === lo ? 0 : (t - lo.position) / (hi.position - lo.position);
    return lo.rgb.map((v, i) => Math.round(v + (hi.rgb[i] - v) * fraction));
  }
  const Surface = L.GridLayer.extend({
    createTile: function(coords) {
      const tile = document.createElement('canvas');
      const size = this.getTileSize();
      tile.width = size.x;
      tile.height = size.y;
      const context = tile.getContext('2d');
      const pixels = context.createImageData(size.x, size.y);
      // Mercator longitude depends only on x; latitude depends only on y.
      const lngs = Array.from({length: size.x}, (_, x) =>
        map.unproject(L.point(coords.x * size.x + x + 0.5, 0), coords.z).lng);
      for (let y = 0; y < size.y; y++) {
        const lat = map.unproject(L.point(0, coords.y * size.y + y + 0.5), coords.z).lat;
        if (lat < COUNTY_BBOX.south || lat > COUNTY_BBOX.north) continue;
        for (let x = 0; x < size.x; x++) {
          const lng = lngs[x];
          if (lng < COUNTY_BBOX.west || lng > COUNTY_BBOX.east) continue;
          const rgb = riskRGB(interpolateGridRisk(lat, lng, gridRisk));
          const offset = (y * size.x + x) * 4;
          pixels.data[offset] = rgb[0];
          pixels.data[offset + 1] = rgb[1];
          pixels.data[offset + 2] = rgb[2];
          pixels.data[offset + 3] = 255;
        }
      }
      context.putImageData(pixels, 0, 0);
      return tile;
    }
  });
  map.createPane('riskSurface');
  map.getPane('riskSurface').style.zIndex = 350;
  map.getPane('riskSurface').style.pointerEvents = 'none';
  new Surface({
    pane: 'riskSurface', opacity: 0.58, tileSize: 256,
    minZoom: 10, maxZoom: 16, noWrap: true,
    bounds: [[COUNTY_BBOX.south, COUNTY_BBOX.west], [COUNTY_BBOX.north, COUNTY_BBOX.east]]
  }).addTo(map);

  /* ---------------- Step 6: Interactive Point Assessment ---------------- */
  let clickMarker = null;

  map.on('click', (e) => {
    const { lat, lng } = e.latlng;
    if (lat < COUNTY_BBOX.south || lat > COUNTY_BBOX.north ||
        lng < COUNTY_BBOX.west || lng > COUNTY_BBOX.east) {
      L.popup().setLatLng(e.latlng).setContent('Outside the modeled area.').openOn(map);
      return;
    }

    const nearestIdx = nearestGridIndex(lat, lng);

    const rainData = weatherRes.data.rain[nearestIdx] || FALLBACK_RAIN7;
    const tempData = weatherRes.data.temp[nearestIdx] || FALLBACK_TEMP7;
    
    const rainScore = rainfallSubscore(rainData);
    const tempScore = temperatureSubscore(tempData);
    const waterScore = waterProximitySubscore(lat, lng, waterRes.data);
    const reportScore = reportSubscore(lat, lng, globeRes.data);

    // Bilinear interpolation avoids snapping the assessment to the nearest cell.
    const risk = interpolateGridRisk(lat, lng, gridRisk);
    const intensity = risk / 100;
    const tier = intensity >= 0.70 ? 'high' : intensity >= 0.35 ? 'medium' : 'low';

    const local7dRain = rainData.reduce((a, b) => a + b, 0);
    const avgTempF = Math.round(tempData.reduce((a, b) => a + b, 0) / tempData.length);

    if (clickMarker) map.removeLayer(clickMarker);

    clickMarker = L.popup()
      .setLatLng([lat, lng])
      .setContent(`
        <div class="popup">
          <div class="pop-title">Location Risk Assessment</div>
          <div class="pop-tier" style="background:${tierBg(tier)};color:${tierColor(tier)}">${tierLabel(tier)}</div>
          <div class="pop-row"><b>Continuous risk score:</b> ${risk.toFixed(1)} / 100</div>
          <div class="pop-row"><b>Coordinates:</b> ${lat.toFixed(4)}, ${lng.toFixed(4)}</div>
          <div class="pop-row"><b>7-Day Rainfall:</b> ${local7dRain.toFixed(2)}"</div>
          <div class="pop-row"><b>Avg Temp:</b> ${avgTempF}°F</div>
          <div class="pop-row"><b>Water Body Risk Factor:</b> ${(waterScore * 100).toFixed(0)}%</div>
        </div>
      `)
      .openOn(map);
  });

  /* ---------------- Step 7: Map Markers ---------------- */
  waterRes.data.forEach(w => {
    L.circleMarker([w.lat, w.lng], {
      radius: 4,
      color: '#2D7D9A',
      weight: 1,
      fillColor: '#DDEEF3',
      fillOpacity: 0.85
    }).bindPopup(`<b>${w.name}</b><br>Standing water feature`).addTo(map);
  });

  const markers = {};
  globeRes.data.forEach(site => {
    let nearestIdx = 0, minDist = Infinity;
    grid.forEach((pt, i) => {
      const d = distanceKm(site.lat, site.lng, pt.lat, pt.lng);
      if (d < minDist) { minDist = d; nearestIdx = i; }
    });
    const siteRisk = gridRisk[nearestIdx];

    const marker = L.circleMarker([site.lat, site.lng], {
      radius: 6,
      color: '#ffffff',
      weight: 1.5,
      fillColor: tierColor(siteRisk.tier),
      fillOpacity: 0.95,
    }).addTo(map);

    marker.bindPopup(`
      <div class="popup">
        <div class="pop-title">${site.name}</div>
        <div class="pop-tier" style="background:${tierBg(siteRisk.tier)};color:${tierColor(siteRisk.tier)}">${tierLabel(siteRisk.tier)}</div>
        <div class="pop-row">${site.larvaeCount > 0 ? `Confirmed larvae (${site.larvaeCount})` : 'No larvae recorded'}</div>
        <div class="pop-row"><b>Water Source:</b> ${site.waterSource}</div>
      </div>
    `);
    markers[site.name] = marker;
  });

  /* ---------------- Step 8: Sidebar Summary Metrics ---------------- */
  document.getElementById('stat-sites').textContent = globeRes.data.length;
  document.getElementById('stat-hot').textContent = gridRisk.filter(s => s.tier === 'high').length;
  document.getElementById('stat-rain').textContent = rain7dTotal.toFixed(1) + '"';

  (function renderRainChart() {
    const chart = document.getElementById('rain-chart');
    const labels = document.getElementById('rain-labels');
    if (!chart || !labels) return;
    chart.innerHTML = '';
    labels.innerHTML = '';

    const max = Math.max(...dailyAvgRain, 0.3);
    dailyAvgRain.forEach((v, i) => {
      const col = document.createElement('div');
      col.className = 'rain-bar-col';
      const bar = document.createElement('div');
      bar.className = 'rain-bar';
      bar.style.height = Math.max(3, Math.round((v / max) * 56)) + 'px';
      col.appendChild(bar);
      chart.appendChild(col);

      const lab = document.createElement('span');
      lab.textContent = RAIN_DAY_LABELS_7[i];
      labels.appendChild(lab);
    });
  })();

  (function renderSiteList() {
    const list = document.getElementById('site-list');
    if (!list) return;
    list.innerHTML = '';

    globeRes.data.forEach(site => {
      const btn = document.createElement('button');
      btn.className = 'site-item';
      btn.innerHTML = `
        <span class="site-dot" style="background:${site.larvaeCount > 0 ? '#EF4444' : '#10B981'}"></span>
        <span class="site-info">
          <div class="site-name">${site.name}</div>
          <div class="site-meta">${site.waterSource} · ${site.larvaeCount} larvae</div>
        </span> 
      `;
      btn.addEventListener('click', () => {
        map.flyTo([site.lat, site.lng], 14, { duration: 0.6 });
        if (markers[site.name]) markers[site.name].openPopup();
      });
      list.appendChild(btn);
    });
  })();

})();
