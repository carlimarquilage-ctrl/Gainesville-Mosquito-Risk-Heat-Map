GAINESVILLE MOSQUITO RISK HEATMAP

1. Extract every file from the ZIP into the same folder.
2. Open index(1).html in Chrome.
3. Keep these filenames unchanged:
   index(1).html
   data(1).js
   risk.js
   api(1).js
   app(1).js
   styles.css

The map tries the live GLOBE Observer, Open-Meteo, and OpenStreetMap sources.
If a source blocks the browser request or is temporarily unavailable, that
source is labeled FALLBACK and the map still renders from sample data.

If Chrome restricts local file requests, run the folder through a local server:

  Windows PowerShell:
  py -m http.server 8000

Then visit:
  http://localhost:8000/index(1).html

